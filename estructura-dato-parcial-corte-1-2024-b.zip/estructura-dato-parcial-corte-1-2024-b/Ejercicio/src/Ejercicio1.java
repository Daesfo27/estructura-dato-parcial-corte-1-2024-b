import javax.swing.*;

import java.util.InputMismatchException;
import java.util.Scanner;

public class Ejercicio1 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Ingrese el nombre del cliente
        System.out.print("Ingrese nombre " +
                "");
        String nombreCliente = scanner.nextLine();

        // Ingresar nombre del producto
        System.out.print("Ingrese el producto" +
                " ");
        String nombreProducto = scanner.nextLine();

        // Ingresa el valor unitario
        double valorUnitario = 0;
        while (true) {
            try {
                System.out.print("Ingrese el valor unitario" +
                        " ");
                valorUnitario = scanner.nextDouble();
                if (valorUnitario <= 0) {
                    System.out.println("Error: el valor unitario debe ser mayor a cero " +
                            "");
                    continue;
                }
                break;
            } catch (InputMismatchException e) {
                System.out.println("Error: el valor unitario debe ser numero" +
                        "");
                scanner.next();
            }
        }

        // Ingresamos cantidad a comprar
        int cantidad = 0;
        while (true) {
            try {
                System.out.print("Ingrese cantidad a la compra" +
                        " ");
                cantidad = scanner.nextInt();
                if (cantidad <= 0) {
                    System.out.println("Error: la cantidad debe mas que cero" +
                            "");
                    continue;
                }
                break;
            } catch (InputMismatchException e) {
                System.out.println("Error: la cantidad tiene que ser un numero que sea entero" +
                        "");
                scanner.next();
            }
        }

        // Calculamos descuento

        double descuento = 0;
        if (cantidad < 10) {
            descuento = 0;
        } else if (cantidad < 20) {
            descuento = 0.05;
        } else {
            descuento = 0.07;
        }

        // Calculamos valor bruto y neto

        double valorBruto = valorUnitario * cantidad;
        double valorNeto = valorBruto * (1 - descuento);

        // Mostrar resultados
        System.out.println("Nombre cliente " + nombreCliente);
        System.out.println("Nombre producto  " + nombreProducto);
        System.out.println("Valor U " + valorUnitario);
        System.out.println("Cantidad  " + cantidad);
        System.out.println("Valor Bruto  " + valorBruto);
        System.out.println("Valor Neto  " + valorNeto);
        System.out.println("Valor Descuento " + (valorBruto - valorNeto));
    }
}